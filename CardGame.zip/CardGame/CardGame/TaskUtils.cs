﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGame
{
    /// <summary>
    /// class for tasks
    /// </summary>
    class TaskUtils
    {
        public static void Shuffle (List<Card> list)
        {
           Random rng = new Random();

            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                Card value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }


        public static void DivideCards(List<Card> Player1, List<Card> Player2, List<Card> deck)
        {
            for(int i = 0; i < 26; i++)
            {
                Player1.Add(deck[i]);
            }
            for(int i = 26; i< 52; i++)
            {
                Player2.Add(deck[i]);
            }
        }

        public static string SelectRandomTrump()
        {
            var random = new Random();
            List<string> listOfTypes = new List<string>();
            listOfTypes.Add("Širdys");
            listOfTypes.Add("Būgnai");
            listOfTypes.Add("Vynai");
            listOfTypes.Add("Kryžiai");

            return listOfTypes[random.Next(listOfTypes.Count)];
        }
        public static List<Card> GenerateCards (string trump)
        {
            List<Card> cards = new List<Card>();
            for(int i = 2; i < 15; i++)
            {
                cards.Add(new Card("Širdys", i, trump));
                cards.Add(new Card("Būgnai", i, trump));
                cards.Add(new Card("Vynai", i, trump));
                cards.Add(new Card("Kryžiai", i, trump));
            }
            return cards;
        }

        public static void Sort(List<Card> cards)
        {
            for (int j = 0; j <= cards.Count - 2; j++)
            {
                for (int i = 0; i <= cards.Count - 2; i++)
                {
                    if (cards[i].CompareTo(cards[i + 1]) <0)
                    {
                        Card temp = cards[i + 1];
                        cards[i + 1] = cards[i];
                        cards[i] = temp;
                    }
                }
            }
        }

        public static void SolveGame(List<Card> cardsPlayer1, List<Card> cardsPlayer2, List<Card> deck1, List<Card> deck2)
        {
            for(int i = 0; i < 26; i++)
            {
                if(cardsPlayer1[i].CompareTo(cardsPlayer2[i]) == 1)
                {
                    deck1.Add(cardsPlayer1[i]);
                    deck1.Add(cardsPlayer2[i]);
                }
                else if(cardsPlayer1[i].CompareTo(cardsPlayer2[i]) == -1)
                {
                    deck2.Add(cardsPlayer1[i]);
                    deck2.Add(cardsPlayer2[i]);
                }
                else
                {
                    deck1.Add(cardsPlayer1[i]);
                    deck2.Add(cardsPlayer2[i]);
                }
            }
        }
    }
}
