﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// data class
/// </summary>
namespace CardGame
{
    class Card
    {
        public string Name { get; set; }
        public int Value { get; set; }
        private bool Trump { get;  set; }

        public Card(string name, int value, string trump)
        {
            this.Name = name;
            this.Value = value;
            if(Name.Equals(trump))
                this.Trump = true;
            else
                this.Trump= false;
        }

        public int CompareTo(Card card)
        {
            if(this.Trump && !card.Trump)
            {
                return 1;
            }
            else if (!this.Trump && card.Trump)
                return -1;
            else
                return this.Value.CompareTo(card.Value);
        }

        public override string ToString()
        {
            if (this.Value == 11)
                return this.Name + " Bartukas";
            else if (this.Value == 12)
                return this.Name + " Dama";
            else if (this.Value == 13)
                return this.Name + " Karalius";
            else if (this.Value == 14)
                return this.Name + " Tūzas";
            else
                return this.Name+ " " + this.Value.ToString();
        }

    }
}
