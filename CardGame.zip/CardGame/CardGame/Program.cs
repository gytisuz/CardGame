﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGame
{
    class Program
    {
        static void Main(string[] args)
        {

            string trump = TaskUtils.SelectRandomTrump();
            Console.WriteLine("Koziriai: " + trump);
            Console.WriteLine(" ");
            List<Card> cards = new List<Card>();

            cards = TaskUtils.GenerateCards(trump);
            TaskUtils.Shuffle(cards);
            //InOut.PrintCards(cards, "KORTOS");

            List<Card> Player1Cards = new List<Card>();
            List<Card> Player2Cards = new List<Card>();
            TaskUtils.DivideCards(Player1Cards, Player2Cards, cards);

            TaskUtils.Sort(Player1Cards);
            TaskUtils.Sort(Player2Cards);
            //InOut.PrintCards(Player1Cards, "Pradinės 1 žaidėjo kortos: ");
            //InOut.PrintCards(Player2Cards, "Pradinės 2 žaidėjo kortos: ");

            List<Card> ScorePile1 = new List<Card>();
            List<Card> ScorePile2 = new List<Card>();

            TaskUtils.SolveGame(Player1Cards,Player2Cards, ScorePile1, ScorePile2);

            InOut.PrintCards(ScorePile1, "1 žaidėjo kortos po žaidimo: ");
            InOut.PrintCards(ScorePile2, "2 žaidėjo kortos po žaidimo: ");

            InOut.PrintResults(ScorePile1, ScorePile2);
            
        }
    }
}
