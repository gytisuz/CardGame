﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGame
{
    class InOut
    {
        public static void PrintCards(List<Card> cards, string header)
        {
            Console.WriteLine(header);
            for (int i = 0; i < cards.Count; i++)
            {
                Console.WriteLine(cards[i].ToString());
            }
        }

        public static void PrintResults(List<Card> ScorePile1, List<Card> ScorePile2)
        {
            if (ScorePile1.Count > ScorePile2.Count)
                Console.WriteLine("Laimėjo 1 žaidėjas");
            else if (ScorePile1.Count < ScorePile2.Count)
                Console.WriteLine("Laimėjo 2 žaidėjas");
            else
                Console.WriteLine("Lygiosios");
        }
    }
}
